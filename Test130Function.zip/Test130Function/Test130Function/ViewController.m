//
//  ViewController.m
//  Test130Function
//
//  Created by ysh on 2020/11/20.
//

#import "ViewController.h"

#import "JSUserTagView.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableview;
@property(nonatomic, strong)JSUserTagView *tagview;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self testTagview];
//    [self begin];
}
#pragma mark tagview

-(void)testTagview
{
    NSArray *arr = @[@"钉钉",@"方法",@"嗯嗯嗯",@"方法",@"嗯嗯嗯",@"方法",@"嗯嗯嗯"];
    NSMutableArray *mutableArr = [NSMutableArray array];
    for (NSString *title in arr) {
        tagModel *model = [[tagModel alloc]init];
        model.title = title;
        model.bgColor = [UIColor orangeColor];
        model.font = [UIFont systemFontOfSize:17];
        model.tagHeight = 20;
        model.marginX = 10;
        model.marginY = 8;
        [mutableArr addObject:model];
    }
    
    
//    testTagView *tagview = [testTagView getTagviewWithArrr:[mutableArr copy]];
    self.tagview = [[JSUserTagView alloc]initWithFrame:CGRectMake(10, 100, 300, 300)];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(taped)];
//    [self.tagview addGestureRecognizer:tap];
    
    self.tagview.userInteractionEnabled = YES;
    [self.tagview setupTagViewWithArrr:[mutableArr copy]];
    self.tagview.backgroundColor = [UIColor grayColor];
    self.tagview.isShowOneRow = YES;
    [self.view addSubview:self.tagview];
    
    
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(100, 50, 100, 30)];
    btn.backgroundColor = [UIColor redColor];
    [self.view addSubview:btn];
    [btn addTarget:self action:@selector(click) forControlEvents:UIControlEventTouchUpInside];
    
}
-(void)taped
{
    NSLog(@"taped");
}

-(void)click
{
    self.tagview.isShowOneRow = !self.tagview.isShowOneRow;
}

#pragma mark tableview
-(void)begin
{
    self.tableview = [[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStylePlain];
    [self.view addSubview:self.tableview];
    [self.tableview registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    self.tableview.delegate = self;
    self.tableview.dataSource = self;
}


#pragma mark tableview datasource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [UITableViewCell new];
    return cell;
}


#pragma mark tableviewdelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}
@end
