//
//  testTagView.m
//  Test130Function
//
//  Created by ysh on 2020/11/20.
//

#import "JSUserTagView.h"

#import <Masonry/Masonry.h>

#define MARGINX 15   //左边距
#define MARGINY 10   //上边距

@implementation tagModel

//

@end

@interface JSUserTagView()
@property(nonatomic,assign)CGFloat viewheight;
@property(nonatomic,assign)CGFloat oneRowHeight;

@end

@implementation JSUserTagView

-(void)setupTagViewWithArrr:(NSArray *)tagArr
{
    
    for (UIView *subview in self.subviews) {
        [subview removeFromSuperview];
    }
    self.userInteractionEnabled = YES;
    CGFloat lastLabX = MARGINX;
    CGFloat lastLabY = MARGINY;
    CGFloat maxWidth = self.frame.size.width -lastLabX;
    CGFloat finalY = lastLabY;
    if (tagArr.count<=0) {
        return;
    }
    for (int i=0; i<tagArr.count; i++) {
        tagModel *model = tagArr[i];
        
        NSString *tagTitle = model.title;
        CGSize size = [self ml_sizeWithFont:model.font maxW:maxWidth text:tagTitle];
        CGFloat tagWidth = size.width +model.tagHeight;
        if (lastLabX+tagWidth>maxWidth) {
            lastLabX = model.marginX;
            lastLabY += model.tagHeight+model.marginY;
        }
        
        UILabel *lab = [[UILabel alloc]init];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(taped:)];
        [lab addGestureRecognizer:tap];
        lab.text = tagTitle;
        lab.userInteractionEnabled = YES;
        lab.textAlignment = NSTextAlignmentCenter;
        lab.backgroundColor = [UIColor orangeColor];
        lab.layer.cornerRadius = model.tagHeight/2.0;
        lab.layer.masksToBounds = YES;
        lab.font = model.font;
        [self addSubview:lab];
        [lab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.mas_equalTo(tagWidth);
            make.height.mas_equalTo(model.tagHeight);
            make.left.mas_equalTo(lastLabX);
            make.top.mas_equalTo(lastLabY);
        }];
        lastLabX += tagWidth + model.marginX;
        finalY = lastLabY +model.marginY+model.tagHeight;
    }
    self.viewheight = finalY;
    tagModel *firstModel = tagArr[0];
    self.oneRowHeight = firstModel.tagHeight+MARGINY+firstModel.marginY;
    [self adaptFrameWithHeight:finalY];
}

-(void)taped:(UIGestureRecognizer *)ges
{
    ges.view.backgroundColor = [UIColor greenColor];
}

-(void)setIsShowOneRow:(BOOL)isShowOneRow
{
    _isShowOneRow = isShowOneRow;
    if (isShowOneRow) {
        [self adaptFrameWithHeight:self.oneRowHeight];
        self.clipsToBounds = YES;
    }else{
        [self adaptFrameWithHeight:self.viewheight];
    }
}

-(void)adaptFrameWithHeight:(CGFloat)height
{
    CGRect newframe = self.frame;
    newframe.size.height = height;
    self.frame = newframe;
}


- (CGSize)ml_sizeWithFont:(UIFont *)font maxW:(CGFloat)maxW text:(NSString *)str
{
    NSMutableDictionary *attrs = [NSMutableDictionary dictionary];
    attrs[NSFontAttributeName] = font;
    CGSize maxSize = CGSizeMake(maxW, MAXFLOAT);
    return [str boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:attrs context:nil].size;
}

@end
