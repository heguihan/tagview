//
//  testTagView.h
//  Test130Function
//
//  Created by ysh on 2020/11/20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface tagModel : NSObject
@property (nonatomic, strong)NSString *title;
@property (nonatomic, strong)UIColor *bgColor;
@property (nonatomic, strong)UIFont *font;
@property (nonatomic, assign)CGFloat tagHeight;
@property (nonatomic, assign)CGFloat marginX;
@property (nonatomic, assign)CGFloat marginY;

@end

@interface JSUserTagView : UIView
@property (nonatomic, assign)BOOL isShowOneRow;
-(void)setupTagViewWithArrr:(NSArray *)tagArr;
@end

NS_ASSUME_NONNULL_END
